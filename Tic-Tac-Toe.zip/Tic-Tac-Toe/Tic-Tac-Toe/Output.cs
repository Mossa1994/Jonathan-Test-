﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    static class Output
    {
        public static void Display(String textToWrite)
        {
            Console.WriteLine(textToWrite);
        }
    }
}
